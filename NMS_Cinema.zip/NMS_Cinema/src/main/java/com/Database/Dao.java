package com.Database;

import com.Model.Movies;
import com.Model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/*
                  To connect to MySql Database JDBC (Hibernate, JPA)
1, Register the Driver -> Class.forName(String className)throws ClassNotFoundException
2, Create connection ->  Connection con = DriverManager.getConnection(String url,String name,String password) throws SQLException
3, Create statement  ->  Statement st = con.createStatement();
4, Execute queries   ->  ResultSet rs = st.executeQuery(query);
5, Close connection  ->  con.close();
*/

public class Dao {
    public Connection con = null;
    public Statement st = null;

    public Dao() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
//        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/NMS_Cinemas", "root", "nathnael");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/NMS_Cinemas", "root", "nathnael");
        System.out.println("connection established with database");

        st = con.createStatement();
    }


    // Method to search all available movies
    public List<Movies> searchMovies(String name) {

        List<Movies> moviesList = new ArrayList<Movies>();

//    String query = "SELECT * FROM NMS_Cinemas.movies where movie_name='" + name + "'";
//        String query = "SELECT * FROM NMS_Cinemas.movies where movie_name='" + name + "'";

        String query = "SELECT * FROM NMS_Cinemas.movies WHERE movie_description";


        try {
            ResultSet result = st.executeQuery(query);

            while (result.next()) {

                String movie_name = result.getString("movie_name");
                String movie_description = result.getString("movie_description");
                String movie_price = result.getString("movie_price");


                Movies moviesDetail = new Movies(movie_name, movie_description, movie_price);
                moviesList.add(moviesDetail);

                return moviesList;
            }
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return null;
    }

    // Method to check user login
    public User validateUser(String email, String password) {
        User loginUser = null;
        String query = "select * from user where email='" + email + "' and password='" + password + "'";
        try {
            ResultSet result = st.executeQuery(query);
            if (result.next()) {
                String userEmail = result.getString("email");
                String userPassword = result.getString("password");
                String userName = result.getString("full_name");
                loginUser = new User(userEmail, userPassword, userName);
            }

            return loginUser;
        } catch (SQLException e) {

            e.printStackTrace();
        }

        return loginUser;
    }

    // Method to add user into user table
    public boolean insertUser(User user) {
        try {
            PreparedStatement state = con.prepareStatement("insert into user " + "(email, password, full_name, dob, phn) values (?,?,?,?,?)");

            state.setString(1, user.getEmail());
            state.setString(2, user.getPassword());
            state.setString(3, user.getName());
            state.setString(4, user.getDateOfBirth());
            state.setString(5, user.getPhoneNumber());

            state.executeUpdate();
            return true;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    // Method to check admin
    public boolean validateAdmin(String email, String password) {

        try {
            ResultSet result = st.executeQuery("select * from admin where email='" + email + "' and password='" + password + "'");
            if (result.next())
                return true;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    // Method to Change Password
    public boolean changeAdminPassword(String email, String password) {

        try {
            ResultSet result = st.executeQuery("select * from admin where email='" + email + "'");
            if (!result.next()) {
                return false;
            }
            st.execute("update admin set password='" + password + "' where email='" + email + "'");
            return true;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    // Method to Add Movies
    public boolean addMovie(Movies fli) {
        try {
            PreparedStatement stat = con
                    .prepareStatement("insert into movies" + "(movie_name, movie_description, movie_price) values (?,?,?)");

            stat.setString(1, fli.getMovieName());
            stat.setString(2, fli.getDescription());
            stat.setString(3, fli.getPrice());

            stat.executeUpdate();
            return true;
        } catch (SQLException e) {

            e.printStackTrace();
            return false;
        }
    }

}



