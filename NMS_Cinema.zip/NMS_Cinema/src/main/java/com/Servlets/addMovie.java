package com.Servlets;

import com.Database.Dao;
import com.Model.Movies;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/addMovie")
public class addMovie extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String movie_name = request.getParameter("movie_name");
        String movie_description = request.getParameter("movie_description");
        String movie_price = request.getParameter("movie_price");

        Movies fli = new Movies(movie_name, movie_description, movie_price);

        try {
            Dao dataBase = new Dao();

            HttpSession session = request.getSession();
            if (dataBase.addMovie(fli)) {
                session.setAttribute("message", "Movie Added Successfully");
            } else {
                session.setAttribute("message", "Error! Please Enter Valid Input");
            }
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
        response.sendRedirect("addMovie.jsp");
    }
}
