package com.Servlets;

import com.Database.Dao;
import com.Model.Movies;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/MovieSearch")
public class MovieSearch extends HttpServlet {

    private static final long serialVersionUID = 1L;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieName = request.getParameter("movieName");


        try {

            Dao dataBase = new Dao();

            List<Movies> moviesList = dataBase.searchMovies(movieName);
            HttpSession session = request.getSession();
            session.setAttribute("movies", moviesList);
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
        response.sendRedirect("moviesList.jsp");
    }
}
