package com.Model;

public class Movies {

    private String movieName;
    private String description;
    private String price;

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Movies(String movieName, String description, String price) {
        this.movieName = movieName;
        this.description = description;
        this.price = price;
    }


}
